
// IMPORTANT: Replace "YOUR_API_KEY_HERE" with your actual Google AI API key.
// The app will not work without a valid key.
export const API_KEY = "YOUR_API_KEY_HERE";
